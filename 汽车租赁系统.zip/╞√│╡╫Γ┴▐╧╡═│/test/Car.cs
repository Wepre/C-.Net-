﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    class Car : Vehicle
    {

        public Car() { }
        public override double sum(int day)
        {
            if (day<=30)
            {
                return DailyRent * day;
            }
            return DailyRent * day*1.1;
        }
        public Car(String lNO, String carname, String color, int rentdate, double dailyrent)
            : base(lNO, carname, color, rentdate, dailyrent)
        {
           
        }
    }
}
