﻿namespace test
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btn_rent = new System.Windows.Forms.Button();
            this.btn_refresh = new System.Windows.Forms.Button();
            this.username = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.carNO = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.carName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.carColor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.useTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.spend = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.trackload = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btn_reback = new System.Windows.Forms.Button();
            this.btn_fresh2 = new System.Windows.Forms.Button();
            this.tb_renteddate = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tb_rentdate = new System.Windows.Forms.TabPage();
            this.tb_load = new System.Windows.Forms.TextBox();
            this.tb_date = new System.Windows.Forms.TextBox();
            this.tb_rentaday = new System.Windows.Forms.TextBox();
            this.tb_carColor = new System.Windows.Forms.TextBox();
            this.tb_carName = new System.Windows.Forms.TextBox();
            this.tb_carNO = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.track = new System.Windows.Forms.RadioButton();
            this.Minicar = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tb_rentdate.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Left;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tb_rentdate);
            this.tabControl1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.tabControl1.ItemSize = new System.Drawing.Size(50, 120);
            this.tabControl1.Location = new System.Drawing.Point(-2, -1);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(745, 490);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 0;
            this.tabControl1.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabControl1_DrawItem);
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btn_rent);
            this.tabPage1.Controls.Add(this.btn_refresh);
            this.tabPage1.Controls.Add(this.username);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.listView1);
            this.tabPage1.Location = new System.Drawing.Point(124, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(617, 482);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "租车";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btn_rent
            // 
            this.btn_rent.Location = new System.Drawing.Point(339, 398);
            this.btn_rent.Name = "btn_rent";
            this.btn_rent.Size = new System.Drawing.Size(75, 23);
            this.btn_rent.TabIndex = 3;
            this.btn_rent.Text = "租车";
            this.btn_rent.UseVisualStyleBackColor = true;
            this.btn_rent.Click += new System.EventHandler(this.btn_rent_Click);
            // 
            // btn_refresh
            // 
            this.btn_refresh.Location = new System.Drawing.Point(199, 398);
            this.btn_refresh.Name = "btn_refresh";
            this.btn_refresh.Size = new System.Drawing.Size(75, 23);
            this.btn_refresh.TabIndex = 3;
            this.btn_refresh.Text = "刷新";
            this.btn_refresh.UseVisualStyleBackColor = true;
            this.btn_refresh.Click += new System.EventHandler(this.btn_refresh_Click);
            // 
            // username
            // 
            this.username.Location = new System.Drawing.Point(261, 356);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(100, 21);
            this.username.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(196, 361);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "租用者";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(258, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "可租车辆";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.carNO,
            this.carName,
            this.carColor,
            this.useTime,
            this.spend,
            this.trackload});
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(0, 31);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(611, 319);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged_1);
            // 
            // carNO
            // 
            this.carNO.Text = "车牌号";
            this.carNO.Width = 128;
            // 
            // carName
            // 
            this.carName.Text = "车名";
            this.carName.Width = 98;
            // 
            // carColor
            // 
            this.carColor.Text = "颜色";
            // 
            // useTime
            // 
            this.useTime.Text = "使用时间";
            this.useTime.Width = 74;
            // 
            // spend
            // 
            this.spend.Text = "日租金";
            this.spend.Width = 76;
            // 
            // trackload
            // 
            this.trackload.Text = "卡车载重";
            this.trackload.Width = 206;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btn_reback);
            this.tabPage2.Controls.Add(this.btn_fresh2);
            this.tabPage2.Controls.Add(this.tb_renteddate);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.listView2);
            this.tabPage2.Location = new System.Drawing.Point(124, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(617, 482);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "还车";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btn_reback
            // 
            this.btn_reback.Location = new System.Drawing.Point(344, 402);
            this.btn_reback.Name = "btn_reback";
            this.btn_reback.Size = new System.Drawing.Size(75, 23);
            this.btn_reback.TabIndex = 6;
            this.btn_reback.Text = "还车";
            this.btn_reback.UseVisualStyleBackColor = true;
            this.btn_reback.Click += new System.EventHandler(this.btn_reback_Click);
            // 
            // btn_fresh2
            // 
            this.btn_fresh2.Location = new System.Drawing.Point(200, 402);
            this.btn_fresh2.Name = "btn_fresh2";
            this.btn_fresh2.Size = new System.Drawing.Size(75, 23);
            this.btn_fresh2.TabIndex = 7;
            this.btn_fresh2.Text = "刷新";
            this.btn_fresh2.UseVisualStyleBackColor = true;
            this.btn_fresh2.Click += new System.EventHandler(this.btn_fresh2_Click);
            // 
            // tb_renteddate
            // 
            this.tb_renteddate.Location = new System.Drawing.Point(270, 352);
            this.tb_renteddate.Name = "tb_renteddate";
            this.tb_renteddate.Size = new System.Drawing.Size(100, 21);
            this.tb_renteddate.TabIndex = 5;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(188, 357);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 16);
            this.label11.TabIndex = 4;
            this.label11.Text = "租用天数";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(278, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 16);
            this.label10.TabIndex = 2;
            this.label10.Text = "结算";
            // 
            // listView2
            // 
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.listView2.FullRowSelect = true;
            this.listView2.GridLines = true;
            this.listView2.Location = new System.Drawing.Point(0, 27);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(611, 319);
            this.listView2.TabIndex = 1;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            this.listView2.SelectedIndexChanged += new System.EventHandler(this.listView2_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "车牌号";
            this.columnHeader1.Width = 128;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "车名";
            this.columnHeader2.Width = 98;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "颜色";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "使用时间";
            this.columnHeader4.Width = 74;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "日租金";
            this.columnHeader5.Width = 76;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "卡车载重";
            this.columnHeader6.Width = 206;
            // 
            // tb_rentdate
            // 
            this.tb_rentdate.Controls.Add(this.tb_load);
            this.tb_rentdate.Controls.Add(this.tb_date);
            this.tb_rentdate.Controls.Add(this.tb_rentaday);
            this.tb_rentdate.Controls.Add(this.tb_carColor);
            this.tb_rentdate.Controls.Add(this.tb_carName);
            this.tb_rentdate.Controls.Add(this.tb_carNO);
            this.tb_rentdate.Controls.Add(this.button2);
            this.tb_rentdate.Controls.Add(this.button1);
            this.tb_rentdate.Controls.Add(this.track);
            this.tb_rentdate.Controls.Add(this.Minicar);
            this.tb_rentdate.Controls.Add(this.label8);
            this.tb_rentdate.Controls.Add(this.label9);
            this.tb_rentdate.Controls.Add(this.label7);
            this.tb_rentdate.Controls.Add(this.label6);
            this.tb_rentdate.Controls.Add(this.label5);
            this.tb_rentdate.Controls.Add(this.label4);
            this.tb_rentdate.Controls.Add(this.label3);
            this.tb_rentdate.Location = new System.Drawing.Point(124, 4);
            this.tb_rentdate.Name = "tb_rentdate";
            this.tb_rentdate.Padding = new System.Windows.Forms.Padding(3);
            this.tb_rentdate.Size = new System.Drawing.Size(617, 482);
            this.tb_rentdate.TabIndex = 2;
            this.tb_rentdate.Text = "录入新车";
            this.tb_rentdate.UseVisualStyleBackColor = true;
            this.tb_rentdate.Enter += new System.EventHandler(this.tabPage3_Enter);
            // 
            // tb_load
            // 
            this.tb_load.Location = new System.Drawing.Point(196, 328);
            this.tb_load.Name = "tb_load";
            this.tb_load.Size = new System.Drawing.Size(153, 21);
            this.tb_load.TabIndex = 3;
            // 
            // tb_date
            // 
            this.tb_date.Location = new System.Drawing.Point(196, 240);
            this.tb_date.Name = "tb_date";
            this.tb_date.Size = new System.Drawing.Size(153, 21);
            this.tb_date.TabIndex = 3;
            // 
            // tb_rentaday
            // 
            this.tb_rentaday.Location = new System.Drawing.Point(196, 285);
            this.tb_rentaday.Name = "tb_rentaday";
            this.tb_rentaday.Size = new System.Drawing.Size(153, 21);
            this.tb_rentaday.TabIndex = 3;
            // 
            // tb_carColor
            // 
            this.tb_carColor.Location = new System.Drawing.Point(196, 195);
            this.tb_carColor.Name = "tb_carColor";
            this.tb_carColor.Size = new System.Drawing.Size(153, 21);
            this.tb_carColor.TabIndex = 3;
            // 
            // tb_carName
            // 
            this.tb_carName.Location = new System.Drawing.Point(196, 144);
            this.tb_carName.Name = "tb_carName";
            this.tb_carName.Size = new System.Drawing.Size(153, 21);
            this.tb_carName.TabIndex = 3;
            // 
            // tb_carNO
            // 
            this.tb_carNO.Location = new System.Drawing.Point(196, 105);
            this.tb_carNO.Name = "tb_carNO";
            this.tb_carNO.Size = new System.Drawing.Size(153, 21);
            this.tb_carNO.TabIndex = 3;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(469, 416);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "入库";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(469, 363);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "重置";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // track
            // 
            this.track.AutoSize = true;
            this.track.Checked = true;
            this.track.Location = new System.Drawing.Point(274, 49);
            this.track.Name = "track";
            this.track.Size = new System.Drawing.Size(47, 16);
            this.track.TabIndex = 1;
            this.track.TabStop = true;
            this.track.Text = "卡车";
            this.track.UseVisualStyleBackColor = true;
            this.track.CheckedChanged += new System.EventHandler(this.track_CheckedChanged_1);
            // 
            // Minicar
            // 
            this.Minicar.AutoSize = true;
            this.Minicar.Location = new System.Drawing.Point(196, 51);
            this.Minicar.Name = "Minicar";
            this.Minicar.Size = new System.Drawing.Size(71, 16);
            this.Minicar.TabIndex = 1;
            this.Minicar.Text = "小型汽车";
            this.Minicar.UseVisualStyleBackColor = true;
            this.Minicar.CheckedChanged += new System.EventHandler(this.Minicar_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(112, 333);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "卡车载重";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(112, 243);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "使用时间";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(112, 288);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "日租金";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(112, 198);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "颜色";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(112, 153);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "车名";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(112, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "车牌号";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(112, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "车类型";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 489);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "汽车租赁系统";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tb_rentdate.ResumeLayout(false);
            this.tb_rentdate.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tb_rentdate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader carNO;
        private System.Windows.Forms.ColumnHeader carName;
        private System.Windows.Forms.ColumnHeader carColor;
        private System.Windows.Forms.ColumnHeader useTime;
        private System.Windows.Forms.ColumnHeader spend;
        private System.Windows.Forms.ColumnHeader trackload;
        private System.Windows.Forms.TextBox username;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_rent;
        private System.Windows.Forms.Button btn_refresh;
        private System.Windows.Forms.TextBox tb_load;
        private System.Windows.Forms.TextBox tb_rentaday;
        private System.Windows.Forms.TextBox tb_carColor;
        private System.Windows.Forms.TextBox tb_carName;
        private System.Windows.Forms.TextBox tb_carNO;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton track;
        private System.Windows.Forms.RadioButton Minicar;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_date;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_reback;
        private System.Windows.Forms.Button btn_fresh2;
        private System.Windows.Forms.TextBox tb_renteddate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;

    }
}

