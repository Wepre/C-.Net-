﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("点击了按钮");
        }

        private void tabControl1_DrawItem(object sender, DrawItemEventArgs e)
        {
            String text = ((TabControl)sender).TabPages[e.Index].Text;
            SolidBrush brush = new SolidBrush(Color.Black);
            StringFormat sf = new StringFormat(StringFormatFlags.DirectionRightToLeft);
            sf.LineAlignment = StringAlignment.Center;
            sf.Alignment = StringAlignment.Center;
            e.Graphics.DrawString(text, SystemInformation.MenuFont, brush, e.Bounds, sf);
        }

        private void btn_rent_Click(object sender, EventArgs e)
        {
            if (username.Text=="")
            {
                MessageBox.Show("租车人姓名不能为空!!");
                return;
               
            }
            my.carListed.Add(my.carList[index]);
            my.carList.RemoveAt(index);
            MessageBox.Show("租车成功！");
            refresh();
        }

        private void tabControl1_TabIndexChanged(object sender, EventArgs e)
        {
            }

        private void tabPage3_Enter(object sender, EventArgs e)
        {
            Minicar.Checked = true;
            tb_load.Enabled = false;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            bool flag = false;
            foreach (Control item in tabControl1.GetControl(2).Controls)
            {
                if (item.Name=="tb_load"&&Minicar.Checked)
                {
                    continue;
                }
                if (item is TextBox && ((TextBox)item).Text=="")
                {
                    flag = true;
                }
            }
            if (flag)
            {
                MessageBox.Show("请输入完整数据");
                return; 
            }
            //MessageBox.Show(count.ToString());
            //System.Threading.Thread.Sleep(5000);
            String lNO = tb_carNO.Text;
            String carname = tb_carName.Text;
            String color = tb_carColor.Text;
            double rent = double.Parse(tb_rentaday.Text);
            int rentdate = int.Parse(tb_date.Text);
            String load;
            if (tb_load.Enabled == false)
            {
                 load = "无";
            }
            else {
                 load = tb_load.Text;
            }
            my.CreateVehical(lNO, carname, color, rentdate, rent, load);
            MessageBox.Show("添加成功！");
        }

        private void track_CheckedChanged(object sender, EventArgs e)
        {
            tb_load.Enabled = true;
        }
        VehicleUtil my = new VehicleUtil(); 
        private void Minicar_CheckedChanged(object sender, EventArgs e)
        {
            tb_load.Enabled = false;
        }
        ListViewItem lt = null;
        private void refresh()
        {
            listView1.Items.Clear();
            foreach (Vehicle vehicle in my.carList)
            {
                lt = new ListViewItem();
                lt.Text = vehicle.LicenseNO;
                lt.SubItems.Add(vehicle.Name);
                lt.SubItems.Add(vehicle.Color);
                lt.SubItems.Add(vehicle.RentDate.ToString());
                lt.SubItems.Add(vehicle.DailyRent.ToString());
                if (vehicle is Car)
                {
                    lt.SubItems.Add("无");
                }
                else
                {
                    Track t = (Track)vehicle;
                    lt.SubItems.Add(t.load.ToString());

                }
                listView1.Items.Add(lt);

            }
        }
        private void refresh2() {
            listView2.Items.Clear();
            foreach (Vehicle vehicle in my.carListed)
            {
                lt = new ListViewItem();
                lt.Text = vehicle.LicenseNO;
                lt.SubItems.Add(vehicle.Name);
                lt.SubItems.Add(vehicle.Color);
                lt.SubItems.Add(vehicle.RentDate.ToString());
                lt.SubItems.Add(vehicle.DailyRent.ToString());
                if (vehicle is Car)
                {
                    lt.SubItems.Add("无");
                }
                else
                {
                    Track t = (Track)vehicle;
                    lt.SubItems.Add(t.load.ToString());

                }
                listView2.Items.Add(lt);

            }
        
        
        }
        private void Form1_Load(object sender, EventArgs e)
        {

            
            foreach (Vehicle vehicle in my.carList)
            {
                lt = new ListViewItem();
                lt.Text = vehicle.LicenseNO;
                lt.SubItems.Add(vehicle.Name);
                lt.SubItems.Add(vehicle.Color);
                lt.SubItems.Add(vehicle.RentDate.ToString());
                lt.SubItems.Add(vehicle.DailyRent.ToString());
                if (vehicle is Car)
                {
                    lt.SubItems.Add("无");
                }
                else
                {
                    Track t = (Track)vehicle;
                    lt.SubItems.Add(t.load.ToString());

                }
                listView1.Items.Add(lt);
            }
        }

        private void tabPage1_Enter(object sender, EventArgs e)
        {
            Console.WriteLine("okk");
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            refresh();
        }

        private void track_CheckedChanged_1(object sender, EventArgs e)
        {
            tb_load.Enabled=true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            foreach (Control item in tabControl1.GetControl(2).Controls) {
                if (item is TextBox)
                {
                    ((TextBox)item).Text = "";
                }
                
            
            }
        }
        int index=0;
        int indexed = 0;
        private void listView1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count!=0)
            {
                index = listView1.SelectedItems[0].Index;
                //MessageBox.Show(index.ToString());
            }
            
        }

        private void tabControl1_Enter(object sender, EventArgs e)
        {
           
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            refresh2();
        }

        private void btn_fresh2_Click(object sender, EventArgs e)
        {
            refresh2();
        }

        private void btn_reback_Click(object sender, EventArgs e)
        {
            int day=0;
            double count = 0;
            if (tb_renteddate.Text == "")
            {
                MessageBox.Show("租车天数不能为空!!");
                return;

            }
            day = int.Parse(tb_renteddate.Text);
            //if (my.carListed[indexed] is Car&&day<=30)
            //{
            //    count = my.carListed[indexed].sum(day);
            //}

            count = my.carListed[indexed].sum(day);
            my.carList.Add(my.carListed[indexed]);
            my.carListed.RemoveAt(indexed);
            MessageBox.Show("你的总价是: "+count);
            refresh();
            refresh2();
            tb_renteddate.Text = "";
        }

        private void listView2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView2.SelectedItems.Count != 0)
            {
                indexed = listView2.SelectedItems[0].Index;
            }
        }

      

    }
}
