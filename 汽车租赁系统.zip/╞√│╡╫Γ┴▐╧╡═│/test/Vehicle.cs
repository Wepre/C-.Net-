﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
   abstract class Vehicle
    {
       public abstract double sum(int day);
      
        private String color;

        public String Color
        {
            get { return color; }
            set { color = value; }
        }
        private String LicenseNO1;

        public String LicenseNO
        {
            get { return LicenseNO1; }
            set { LicenseNO1 = value; }
        }
        private String Name1;

        public String Name
        {
            get { return Name1; }
            set { Name1 = value; }
        }
        private String RentUser1;

        public String RentUser
        {
            get { return RentUser1; }
            set { RentUser1 = value; }
        }
        private int RentDate1;

        public int RentDate
        {
            get { return RentDate1; }
            set { RentDate1 = value; }
        }
        private int YearsOfService1;

        public int YearsOfService
        {
            get { return YearsOfService1; }
            set { YearsOfService1 = value; }
        }
        private double DailyRent1;

        public double DailyRent
        {
            get { return DailyRent1; }
            set { DailyRent1 = value; }
        }
       public Vehicle() { }
       public Vehicle(String lNO, String carname, String color, int rentdate, double dailyrent)
        {
            this.LicenseNO=lNO;
             this.Name=carname;
             this.Color=color;
             this.RentDate=rentdate;
            this.DailyRent=dailyrent;
        }
    }
}
