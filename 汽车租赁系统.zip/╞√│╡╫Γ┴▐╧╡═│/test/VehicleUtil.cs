﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace test
{
    class VehicleUtil
    {
        public List<Vehicle> carList = new List<Vehicle>();
        public List<Vehicle> carListed = new List<Vehicle>();      
       public VehicleUtil()
       {
           Car car1 = new Car("赣A12345", "宝马", "蓝", 5, 1111);
           Car car2 = new Car("赣A15435", "奥迪", "白", 5, 2121);
           Car car3 = new Car("赣A17765", "奥拓", "蓝", 23, 123);
           Car car4 = new Car("赣A15445", "丰田", "红", 59, 2121);
           Track track1 = new Track("赣A15445", "丰田", "红", 59, 2121,4);
           Track tracked1 = new Track("琼B87631", "兰博基尼", "白", 59, 4455, 2);
           carList.Add(car1);

           carList.Add(car2);
           carList.Add(car3);
           carList.Add(car4);
           carList.Add(track1);
           carListed.Add(tracked1);
       }
       public void CreateVehical(String lno,String carname,String color,int rentdate,double rent,String load ) {

           if (load == "无")
           {
               carList.Add(new Car(lno, carname, color, rentdate, rent));
               
           }
           else {

               carList.Add(new Track(lno, carname, color, rentdate, rent,int.Parse(load)));
           }
       }
    }
}
