﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    class Track:Vehicle
    {
        private int Load;
        public override double sum(int day)
        {
            if (day <= 30)
            {
                return DailyRent * day;
            }
            return (DailyRent*(10+load)/10) * (day - 30) + DailyRent * day;
        }
        public int load
        {
            get { return Load; }
            set { Load = value; }
        }
        public Track(String lNO, String carname, String color, int rentdate, double dailyrent, int load) : base(lNO, carname, color, rentdate, dailyrent) { Load = load; }
    }
}
